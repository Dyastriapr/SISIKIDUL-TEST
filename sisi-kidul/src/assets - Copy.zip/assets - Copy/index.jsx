import logo from "./logo/logo.png"
import HeroBg from "./image/Hero2.png"
import vectorFaq from "./image/vector-question.png"
import about from "./image/about.png"
import TPS from "./logo/TPS.png"
import kemendikbud from "./logo/kemendikbud.jpg"
import bogor from "./logo/Bogor.png"
import naungan from "./logo/naungan.png"
import fondasi1 from "./logo/Fondasi1.png"
import fondasi2 from "./logo/Fondasi2.png"
import fondasi3 from "./logo/Fondasi3.png"
import fondasi4 from "./logo/Fondasi4.png"
import fondasi5 from "./logo/Fondasi5.png"
import fondasi6 from "./logo/Fondasi6.png"
import SaranaInformasi from "./logo/SaranaInformasi-02.png"
import Vector from "./logo/Vector2.png"
import modul from './logo/modul.png'
import galeri1 from "./image/image1.jpg"
import galeri2 from "./image/image2.jpg"
import galeri3 from "./image/image3.jpg"
import galeri4 from "./image/image4.jpg"

import webinar1 from "./image/webinar1.jpeg"
import webinar2 from "./image/webinar2.jpeg"
import webinar3 from "./image/webinar3.jpeg"
import webinar4 from "./image/webinar4.jpeg"
import webinar5 from "./image/webinar5.jpeg"
import webinar6 from "./image/webinar6.jpeg"
import webinar7 from "./image/webinar7.jpeg"
import webinar8 from "./image/webinar8.jpeg"

import pdf1 from "./pdf/modul1.pdf"
import pdf2 from "./pdf/modul2.pdf"
import pdf3 from "./pdf/modul3.pdf"
import pdf4 from "./pdf/modul4.pdf"
import testpdf from "./pdf/testpdf.pdf"

import video from "./video/Video.mp4"

import FotoProfil from './image/FotoProfil.jpeg'



export {pdf1 ,video, modul,vectorFaq , testpdf,pdf2,pdf3,pdf4 ,logo , Vector,  HeroBg , TPS, kemendikbud , bogor , naungan , about, fondasi1 ,fondasi2 , fondasi3,fondasi4,fondasi5,fondasi6, SaranaInformasi , galeri1 ,galeri2 ,galeri3 ,galeri4 , FotoProfil , webinar1 ,webinar2 ,webinar3 ,webinar4,webinar5,webinar6,webinar7,webinar8}